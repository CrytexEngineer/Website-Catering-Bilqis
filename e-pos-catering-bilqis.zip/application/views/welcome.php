<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://localhost/e-pos-catering-bilqis/assets/welcome.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta charset="utf-8">

    <title></title>

    <script>
			alert("Selamat Datang Dan Salam Kenal");
		</script>
  </head>

  <body>

    <!-- A grey horizontal navbar that becomes vertical on small screens -->
    <div class="background">
  <h1 id="backgroundText">  " L     E     A     R     N    "</h1>
</div>


<nav class="navbar sticky-top  navbar-expand-sm bg-light navbar-light">
<ul class="navbar-nav">
<li class="nav-item ">
  <a class="nav-link" href="#row">Get to Know</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="https://www.instagram.com/m.aqilm/?hl=id">Intagram</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="https://www.linkedin.com/in/muhammad-aqil-maulana-9a4aa1141/">Linked In</a>
</li>
</ul>
</nav>


<div class="jumbotron jumbotron-fluid">
  <div class="container">
<div class="a"  class="font-weight-light"><h5>-Kemenangan Adalah Impian Setiap Orang,
  Namun Terkadang Kita Harus Belajar-</br></h5></p>
  </div>
</div>
</div>
<div class="background2">


<div class="explain" id="row"><p>a Brief Explanation About Me</p></div>

<div class="row" >
  <div class="col-sm-4"><div class="profile"><div class="card" style="width:300px">
<img class="card-img-top" src="img2.jpg" alt="Card image">
<div class="card-body">
  <h4 class="card-title">Who am i? </h4>
  <p class="card-text">Nama saya Muhammad Aqil Maulana, Seorang mahasiswa semeseter 4 yang berkuliah di Institut teknologi Kalimantan. Saya Lahir di sebuah kota kecil bernama Kefamenanu pada tanggal 23 juli 1997, Saya menyukai berbagai hal yang berkaitan dengan perkembangan teknologi, fotografi, dan kemanusiaan
  </div></p>
  <a href="https://www.linkedin.com/in/muhammad-aqil-maulana-9a4aa1141/" class="btn btn-primary">See Full Profile</a>
</div>
</div>
</div>

  <div class="col-sm-4"><div class="profile"><div class="card" style="width:300px">
<img class="card-img-top" src="img3.jpg" alt="Card image">
<div class="card-body">
  <h4 class="card-title">What i Believe? </h4>
  <p class="card-text">Saya selalu percaya bahwa setiap orang selalu memliliki tanggung jawab terhadap dirinya masing-masing, tanggung jawab untuk menjadi lebih baik , tanggung jawab untuk menjadi dewasa , dan tanggung jawab kepada sang pencipta
  </div></p>
  <a href="#dsc" class="btn btn-primary">See My Achievement</a>
</div>
</div>
</div>

  <div class="col-sm-4"><div class="profile"><div class="card" style="width:300px">
 <div class="card" style="width:300px">
<img class="card-img-top" src="img4.jpg" alt="Card image">
<div class="card-body">
  <h4 class="card-title">What is my Mission? </h4>
  <p class="card-text">Saya ingin meberikan pengalaman yang menyenangkan bagi orang orang disekitar saya, Saya ingin agar setiap prestasi dan Ilmu yang saya buat dapat membuat hidup orang lain menjadi lebih mudah, Saya ingin menjadi penggerak yang dapat membuat dampak positif bagi lingkungan di sekitar saya
  </div></p>
  <a href="#dsc" class="btn btn-primary">See what i've done</a>
</div>

</div>
</div>
</div>
</div>

<div class="background3">
<h3 id="backgroundText3"  class="font-weight-light">  -This is Me- "</h1>
</div>


<div class="row">
  <div class="col-sm-4"><div class="profile"><div class="card" style="width:300px">
<img class="card-img-top" src="img7.jpg" alt="Card image">
<div class="card-body">
  <h4 class="card-title">Student Trainer</h4>
  <p class="card-text">Melalui Kepemanduan di Institut Teknologi Kalimantan, Saya membantu ratusan mahasiswa untuk beradapatasi menghadapi dunia perkuliahan. Saya mengajarkan manajemen waktu
    dan kepemimpinan yang akan menunjang karir mereka
  </div></p>

</div>
</div>
</div>

  <div class="col-sm-4"><div class="profile"><div class="card" style="width:300px">
<img class="card-img-top" src="img8.jpg" alt="Card image">
<div class="card-body">
  <h4 class="card-title">Menunjang Komitmen 1000 Developer Dari Google Untuk Indonesia </h4>
  <p class="card-text">Saya terpilih sebagai Developer Student Club untuk Institut Teknologi Kaliamantan, dengan demikian saya ikut serta dalam menunjang terciptanya komitmen 1000 developer android di seluruh indonesia
  </div></p>

</div>
</div>
</div>

  <div class="col-sm-4"><div class="profile" id="dsc"><div class="card" style="width:300px">
 <div class="card" style="width:300px">
<img class="card-img-top" src="img4.jpg" alt="Card image">
<div class="card-body">
  <h4 class="card-title">Menanamkan Budaya Developer </h4>
  <p class="card-text">Melalui developer student club , saya telah membatu 63 mahasiswa baru untuk mengahadpai ujian tengah semester algloritma dan pemrogaman. Sejatinya pelatihan ini diadakan untuk menanamkan sebuah konsep "coding is fun" kepada mahasiswa baru sejak dini
  </div></p>

</div>

</div>
</div>
</div>
</div>





    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
